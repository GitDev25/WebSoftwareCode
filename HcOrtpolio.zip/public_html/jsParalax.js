(function() {
            
            var documentEl = $(document),
                parallaxBg = $('main');
            
            documentEl.on('scroll', function() {
                var currScrollPos = documentEl.scrollTop();
                parallaxBg.css('background-position', '0 ' + -currScrollPos/4 + 'px');
            });
            
            
            
        })();