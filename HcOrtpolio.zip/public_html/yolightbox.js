// set up event listener for player status
function vzaarPlayerReady() {
vzPlayer = document.getElementById("video");
vzPlayer.addEventListener("playState", "showPlayerStatus");
alert("ready");
}
function showPlayerStatus(state) {
alert(state);
}

// play the video
function playVzaarVideo() {
vzPlayer.play2();
}

// get the video duration
function getVzaarVideoDuration() {
totalTime = vzPlayer.getTotalTime();
alert(totalTime);
}