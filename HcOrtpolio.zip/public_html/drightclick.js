
    document.onmousedown=disableclick;
  //  status="Sorry But I'm Trying to Protect my Source code";
    function disableclick(event)
    {
      if(event.button==2)
       {
        // alert(status);
         return false;    
       }
    }
    

